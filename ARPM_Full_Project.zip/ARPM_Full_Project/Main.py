from step1.riskdrivers import step1
from step2.quest_for_invariant import step2
from step3.Estimation import step3
from step4.projection import step4
from step5.Pricing import step5
from step6.Aggregation import step6
from step7.Evaluation import step7
from step8.Attribution import step8
from step9.Construction import step9
from step10.Execution import step10

def Main():
    step1()
    print("step 1 done")
    step2()
    print("step 2 done")
    step3()
    print("step 3 done")
    step4()
    print("step 4 done")
    step5()
    print("step 5 done")
    step6()
    print("step 6 done")
    step7()
    print("step 7 done")
    step8()
    print("step 8 done")
    step9()
    print("step 9 done")
    step10()
    print("step 10 done")
    print('whole done...')

if __name__ == '__main__':
    Main()
