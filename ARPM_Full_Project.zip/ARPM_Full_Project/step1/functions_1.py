import numpy as np
from scipy.stats import norm



def Delta_to_M(implvol_delta_moneyness_2d, dates, delta, tau, y, n_grid_option):
    l_ = len(tau)
    t_ = len(dates)
    n_grid = n_grid_option
    implied_volatility = []

    for t in range(t_):
        impvol_m_moneyness = []
        for l in range(l_):
            sigma_delta = np.r_[np.array(implvol_delta_moneyness_2d.iloc[t, l::l_])]
            m = norm.ppf(delta) * sigma_delta - (y + sigma_delta ** 2 / 2) * np.sqrt(tau[l])
            m_grid = np.min(m) + (np.max(m) - np.min(m)) * np.arange(n_grid + 1) / n_grid

            poly_coef = np.polyfit(m.flatten(), sigma_delta.flatten(), 2)
            polyf = np.poly1d(poly_coef)
            sigma_m_moneyness = polyf(m_grid.flatten())
            impvol_m_moneyness.extend(sigma_m_moneyness)
        implied_volatility.append(impvol_m_moneyness)
    m = m_grid

    return implied_volatility, m


def bsm_price(s, k, rf, tau, v, div=0, cp=1):

    d1 = (np.log(s / k) + (rf - div + 0.5*v**2) * tau) / (v * np.sqrt(tau))
    d2 = d1-v*np.sqrt(tau)

    option_price = cp*s*np.exp(-div*tau)*norm.cdf(cp*d1) -\
        cp*k*np.exp(-rf*tau)*norm.cdf(cp*d2)

    return option_price

