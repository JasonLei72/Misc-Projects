import numpy as np
import pandas as pd
import datetime
from scipy import interpolate
import matplotlib.pyplot as plt
from matplotlib._pylab_helpers import Gcf
from step1.functions_1 import Delta_to_M, bsm_price

# This script applies the first step - Risk drivers identification

def step1():

    # 1. input parameters
    stock_names = ['AMZN','BBY', 'BOA', 'CLF', 'DOV', 'FOX', 'JPM']  # stocks names

    strike = 1407 # strike of the options on the S&P500 (in dollars)
    t_end_option = np.datetime64('2013-08-26')  # expiry date of the options
    n_grid_option = 8  # num. of points on the moneyness grid is n_grid_option+1


    # 2. import data

    # stocks
    #path = '/Users/heruojing/Desktop/ARPM/results/'
    stocks = pd.read_csv( 'Stocks.csv', index_col= 0)
    stocks.index = pd.to_datetime(stocks.index)

    # implied volatility of call option on S&P500 index
    option_impvol = pd.read_csv( 'data.csv', parse_dates=['date'], keep_date_col=True)
    implvol_param = pd.read_csv( 'params.csv', index_col=0)


    # intersect dates
    dates = pd.to_datetime(np.array(stocks.index))
    ### change the code after knowing how HOLDINGS works
    dates = np.intersect1d(dates, np.array(option_impvol.loc[:, 'date']))
    #dates = np.intersect1d(dates, np.array(db_vix.loc[:, 'date']))
    dates = dates.astype('datetime64[D]')
    # length of the time series
    t_ = len(dates)


    # current time
    t_now = dates[-1]


    # initialize temporary databases
    risk_drivers = {}
    v_tnow = {}
    risk_drivers_names = {}
    v_tnow_names = {}


    # 3. risk driver for stocks

    n_stocks = len(stock_names)
    for n in range(n_stocks):
        risk_drivers[n] = np.log(np.array(stocks.loc[dates, stock_names[n]]))
        risk_drivers_names[n] = 'stock ' + stock_names[n] + '_log_value'
        v_tnow[n] = stocks.loc[dates[-1], stock_names[n]]
        v_tnow_names[n] = 'stock ' + stock_names[n]

    # number of risk drivers, to be updated at every insertion
    d_ = n_stocks


    # 4. risk driver for index

    risk_drivers[d_] = np.log(np.array(option_impvol.loc[(option_impvol['date'].isin(dates)), 'underlying']))
    risk_drivers_names[d_] = 'sp_index_log_value'
    v_tnow[d_] = option_impvol.loc[(option_impvol['date'] == dates[-1]), 'underlying'].values[0]
    v_tnow_names[d_] = 'sp_index'

    # update counter
    d_ = d_+1


    # 5. risk driver for options

    # yield curve (assumed flat and constant)
    y = 0.01

    # implied volatility parametrized by time to expiry and delta-moneyness
    option_tau = np.array(implvol_param.index)
    option_tau = option_tau[~np.isnan(option_tau)]
    l_tau = len(option_tau)

    option_delta = np.array(implvol_param.delta)

    implied_volatility_delta = option_impvol.loc[(option_impvol['date'].isin(dates)),
                                                 (option_impvol.columns != 'date') & (option_impvol.columns != 'underlying')]


    implied_volatility_m, option_m = Delta_to_M(implied_volatility_delta, dates, option_delta, option_tau, y, n_grid_option)
    log_implied_volatility_m = np.log(implied_volatility_m)


    # current value of the underlying
    s_tnow = v_tnow[n_stocks]

    tau_option_tnow = np.timedelta64(t_end_option - t_now, 'D') / \
                      np.timedelta64(252, 'D')

    # current moneyness
    m_tnow = np.log(s_tnow/strike)/np.sqrt(tau_option_tnow)

    # current implied volatility (interpolated for the current time to expiry and moneyness)

    # grid points
    points = list(zip(*[grid.flatten() for grid in np.meshgrid(*[option_tau,option_m])]))

    # known values
    values = implied_volatility_m[-1]

    # interpolation
    implied_volatility_tnow = \
        interpolate.LinearNDInterpolator(points, values)(*np.r_[tau_option_tnow,
                                                                m_tnow])

    # compute call option value by means of Black-Scholes-Merton formula
    v_call_tnow = bsm_price(s_tnow, strike, y, tau_option_tnow,
                            implied_volatility_tnow)

    # compute put option value by means of Black-Scholes-Merton formula
    v_put_tnow = bsm_price(s_tnow, strike, y, tau_option_tnow,
                           implied_volatility_tnow, 0, -1)


    # store data
    d_impvol = log_implied_volatility_m.shape[1]
    for d in np.arange(d_impvol):
        risk_drivers[d_ + d] = log_implied_volatility_m[:, d]
        risk_drivers_names[d_+d] = 'option_spx_logimplvol_mtau_' + str(d+1)

    v_tnow[d_] = v_call_tnow
    v_tnow_names[d_] = 'option_spx_call'
    v_tnow[d_+1] = v_put_tnow
    v_tnow_names[d_+1] = 'option_spx_put'

    # update counter
    d_ = len(risk_drivers)
    n_ = len(v_tnow)



    # 6. save databases

    out = pd.DataFrame({risk_drivers_names[d]: risk_drivers[d]
                        for d in range(len(risk_drivers))}, index=dates)
    out = out[list(risk_drivers_names.values())]
    out.index.name = 'dates'
    out.to_csv('db_riskdrivers_series.csv')
    del out


    out = pd.DataFrame({v_tnow_names[n]: pd.Series(v_tnow[n])
                       for n in range(len(v_tnow))})
    out = out[list(v_tnow_names.values())]
    out.to_csv('db_v_tnow.csv',
               index=False)
    del out


    out = {'n_stocks': pd.Series(n_stocks),
           'd_impvol': pd.Series(d_impvol),
           'tend_option': pd.Series(t_end_option),
           'tnow': pd.Series(t_now),
           'k_strike': pd.Series(strike),
           'l_': pd.Series(l_tau),
           'n_grid_option': pd.Series(n_grid_option),
           'tau_implvol': pd.Series(option_tau),
           'y': pd.Series(y),
           'm_moneyness': pd.Series(option_m),
           'd_': pd.Series(d_)}
    out = pd.DataFrame(out)
    out.to_csv('db_riskdrivers_tools.csv',
               index=False)
    del out


    # 7. plots


    #plot the risk driver of the first stock
    plt.style.use('seaborn')
    d = 0

    f = plt.figure(figsize= (12,6))
    f = plt.plot(dates, risk_drivers[d])
    plt.title(risk_drivers_names[d], fontweight='bold')
    plt.xlabel('time (days)')
    plt.xlim([dates[0], dates[-1]])

    [fig_manager.canvas.figure.set_size_inches(10, 8)
     for fig_manager in Gcf.get_all_fig_managers()]

    plt.savefig('figure_riskdriver.png')
    plt.show(block=False)






