import numpy as np
import pandas as pd
from scipy.stats import norm
import matplotlib.pyplot as plt
from scipy import interpolate


def step10():
    
    #Input Parameter
    qnow = 0																						
    qend = 1
    k_ = 300
    alpha = 1
    l_ = 500
    c = 0.95
    gamma = 0.314  # permanent impact parameter
    eta = 0.0142  # temporary impact parameter

    """Step 0: Load data"""
    # Risk drivers identification
    db_riskdrivers_tools = pd.read_csv('db_riskdrivers_tools.csv')
    n_stocks = int(db_riskdrivers_tools['n_stocks'][0])                                                           # number of stocks
    n_ = n_stocks+3    				                                                                                    # number of instruments

    # Aggregation
    db_holdings = pd.read_csv('db_holdings.csv')
    h_qnow = np.squeeze(db_holdings.values)   

    db_v_tnow = pd.read_csv('db_v_tnow.csv') 																						# database of assets' value
    v_tnow = db_v_tnow.values[0] 


    # Redo step 4 and step 5 to compute daily P&L by setting m_=1

    db_riskdrivers_series = pd.read_csv('db_riskdrivers_series.csv',index_col=0) 				# database of risk drivers
    riskdriver_series_values = db_riskdrivers_series.values 

    j_ = 125
    db_projection_riskdrivers = pd.read_csv('db_projection_riskdrivers.csv')
    riskdriver_series_values_proj = db_projection_riskdrivers.values.reshape(j_, 41, 98) 		

    pi_tnow_thor2 = np.zeros((j_, n_))
    for n in range(n_stocks):
        pi_tnow_thor2[:, n] = v_tnow[n] * (np.exp(riskdriver_series_values_proj[:, 1, n] - riskdriver_series_values[1, n])-1)

    pi_tnow_thor2[:, n_stocks] = v_tnow[n_stocks]*(np.exp(riskdriver_series_values_proj[:, 1, n_stocks] - riskdriver_series_values[1, n_stocks])-1)


    tend_option = pd.to_datetime(db_riskdrivers_tools['tend_option'][0])
    db_projection_tools = pd.read_csv('db_projection_tools.csv')
    thor = pd.to_datetime(db_projection_tools['thor'][0])
    tau_opt_thor = np.timedelta64(np.datetime64(tend_option) - np.datetime64(thor), 'D')/np.timedelta64(252, 'D')

    v_call_thor2 = np.zeros(j_)																																																# construct series for V_call
    v_put_thor2 = np.zeros(j_)														    																																	# construct series for V_put
    mon_thor2 = np.zeros(j_)																																																		# construct series for moneyness
    logsigma_interp2 = np.zeros(j_)   																																													# construct series for interpolation

    s_thor2 = np.exp(riskdriver_series_values_proj[:, 1, n_stocks])
    k_strike = db_riskdrivers_tools['k_strike'][0]																																																																# underlying value at t_horizon of each scenarios
    mon_thor2 = np.log(s_thor2/k_strike)/np.sqrt(tau_opt_thor)																																	# calculate moneyness

    l_tau = int(db_riskdrivers_tools['l_'][0])		   																																							# length of tau
    n_grid_option = int(db_riskdrivers_tools['n_grid_option'][0])	
    d_impvol = int(db_riskdrivers_tools['d_impvol'][0])
																														# value of n_grid
    logsigma_thor = riskdriver_series_values_proj[:, 1, n_stocks+1:n_stocks+d_impvol+1].reshape(j_, l_tau, n_grid_option+1)	

    tau_implvol = db_riskdrivers_tools['tau_implvol'].values																																	# array of tau values	
    m_moneyness = db_riskdrivers_tools['m_moneyness'].values[:n_grid_option+1] 																								# n_grid + 1
    y = db_riskdrivers_tools['y'][0]																																													# risk free rate

    for j in range(j_):
        points = list(zip(*[grid.flatten()
                            for grid in np.meshgrid(*[tau_implvol, m_moneyness])]))
        values = logsigma_thor[j, :, :].flatten('F')
        moneyness_hor = min(max(mon_thor2[j], min(m_moneyness)), max(m_moneyness))
        logsigma_interp2[j] = interpolate.LinearNDInterpolator(points, values)(*np.r_[tau_opt_thor, moneyness_hor])

    def bsm_price(s, k, rf, tau, v, div=0, cp=1):
        d1 = (np.log(s / k) + (rf - div + 0.5*v**2) * tau) / (v * np.sqrt(tau))
        d2 = d1-v*np.sqrt(tau)
        optprice = cp*s*np.exp(-div*tau)*norm.cdf(cp*d1) - cp*k*np.exp(-rf*tau)*norm.cdf(cp*d2)
        return optprice

    v_call_thor2 = bsm_price(s_thor2, k_strike, y, tau_opt_thor, np.exp(logsigma_interp2))
    v_put_thor2 = bsm_price(s_thor2, k_strike, y, tau_opt_thor, np.exp(logsigma_interp2), 0, -1)

    pi_tnow_thor2[:, n_stocks+1] = v_call_thor2 - v_tnow[n_stocks+1]
    pi_tnow_thor2[:, n_stocks+2] = v_put_thor2 - v_tnow[n_stocks+2]

    db_pi_oneday = pd.DataFrame(pi_tnow_thor2)
    pi_oneday = db_pi_oneday.values[:, :n_]




    # Construction
    db_final_portfolio = pd.read_csv('db_final_portfolio.csv')
    # the final portfolio is the one obtained in the construction step,
    # that optimizes the cVaR index of satisfaction
    h_qend = np.squeeze(db_final_portfolio.values)                                                                # final holdings # optimal holdings
    
    """Step 1: Find trajectory"""
    sigma = np.zeros((n_, 1))
    for n in np.arange(n_):
        sigma[n, 0] = np.std(pi_oneday[n, :])																																			# standard deviation of PnL

    # parent order
    delta_h_parent = h_qend - h_qnow

    beta = np.linspace(alpha/(1+alpha), 1, l_+1, endpoint=True)
    beta = beta[1:]
    q_grid = np.arange(qnow, qend, (1/k_))

    variance_pihat = np.zeros((n_, l_))
    mean_pihat = np.zeros((n_, l_))
    quantile_index = np.zeros((n_, l_))
    traj = np.zeros((n_, l_, k_))

    for l in range(l_):
        for n in range(n_):
            if h_qnow[n] == h_qend[n]:
                # if the starting and final holdings are the same we don't need to
                # calculate trajectory
                traj[n, l, :] = np.tile(h_qend[n], k_)
            else:
                def trajectory(q):
                    return (h_qnow[n] + ((q-qnow)/(qend-qnow))**beta[l]*delta_h_parent[n])
                xi = beta[l]**(alpha+1)/(beta[l]+beta[l]*alpha-alpha)
                mean_pihat[n, l] = gamma/2*(h_qend[n]**2 - h_qnow[n]**2) - \
                    eta*xi*np.abs(delta_h_parent[n])**(1+alpha) * \
                    (qend-qnow)**(-alpha)
                variance_pihat[n, l] = sigma[n, 0]**2 * (qend-qnow) * \
                    (h_qnow[n]**2 + 2*h_qnow[n]*delta_h_parent[n]/(beta[l]+1) +
                     (delta_h_parent[n]**2)/(2*beta[l]+1))
                quantile_index[n, l] = norm.ppf(1-c, mean_pihat[n, l],
                                                np.sqrt(variance_pihat[n, l]))

                traj[n, l, :] = trajectory(q_grid)



    """Step 2: Maximization"""
    beta_star = np.zeros((n_, 1))
    ind_beta_star = np.zeros((n_, 1))
    for n in range(n_):
        if h_qnow[n] == h_qend[n]:
            beta_star[n, 0] = beta[-1]
        else:
            ind_beta_star[n, 0] = \
                np.where(quantile_index[n, :] == np.max(quantile_index[n, :]))[0]
            # beta corresponding to the optimal liquidation trajectory
            beta_star[n, 0] = beta[np.int(ind_beta_star[n, 0])]
        
    """Plot"""
    #plot execution trajectories
    plt.style.use('seaborn')
    plt.figure()
    n = np.int(np.argmin(beta_star))  # select instrument
    for i in range(0, l_, 50):
        plt.plot(q_grid, np.squeeze(traj[n, i, :]), color='grey')
    plt.plot(q_grid, np.squeeze(traj[n, np.int(ind_beta_star[n]), :]), color='red')
    plt.title('Optimal liquidation trajectory - ' + str(db_pi_oneday.columns[n]))
    plt.xlabel('Volume time')
    plt.ylabel('Holdings')
    
    plt.savefig('execution.png')
    plt.show(block=False)