import numpy as np
from scipy.optimize import minimize


##computes the expectation and covariance of a scenario-probability distribution
def mean_cov(x):

    t_ = x.shape[0]
    p = np.ones(t_) / t_  # equal probabilities as default value

    mean = p @ x
    cov = ((x-mean).T*p) @ (x-mean)

    return mean, cov


def fit_garch(df, sigma2_0=None, param0=None, g=0.95, rescale=False):

    # Step 0: Setup default values
    t_ = df.shape[0]

    # assuming equal probabilities
    p = np.ones(t_) / t_

    # sample mean and variance
    if (sigma2_0 is None) or (param0 is None) or (rescale is True):
        mean, cov = mean_cov(df)

    # initial value of sigma2_t
    if sigma2_0 is None:
        sigma2_0 = cov

    # initial parameters, the default value is such that a + b = g <1 and
    # c / (1 - a - b) = cov
    if param0 is None:
        param0 = [0.01, g - 0.01, cov * (1. - g), mean]  # initial parameters

    # standardize data if true
    if rescale is True:
        df = (df - mean) / np.sqrt(cov)
        param0[2] = param0[2] / cov
        param0[3] = param0[3] - mean
        sigma2_0 = sigma2_0 / cov

    # Step 1: Compute negative log-likelihood of GARCH

    def llh(param):
        a, b, c, mu = param
        sigma2 = sigma2_0
        llh = 0.0
        for t in range(t_):
            llh = llh + ((df[t] - mu) ** 2 / sigma2 + np.log(sigma2)) * p[t]
            sigma2 = c + a * (df[t] - mu) ** 2 + b * sigma2

        return llh

    # Step 2: Minimize the negative log-likelihood

    # parameter boundaries
    bnds = ((1e-20, 1.), (1e-20, 1.), (1e-20, None), (None, None))
    # stationary constraints
    cons = {'type': 'ineq', 'fun': lambda param: g - param[0] - param[1]}
    a, b, c, mu = minimize(llh, param0, bounds=bnds, constraints=cons)['x']

    # Step 3: Compute realized volatilities and residuals

    sigma2 = np.full(t_, sigma2_0)
    for t in range(t_ - 1):
        sigma2[t + 1] = c + a * df[t] ** 2 + b * sigma2[t]
    epsi = (df - mu) / np.sqrt(sigma2)

    if rescale is True:
        c = c * cov
        mu = mu * np.sqrt(cov) + mean
        sigma2 = sigma2 * cov

    return [a, b, c, mu], sigma2, epsi



