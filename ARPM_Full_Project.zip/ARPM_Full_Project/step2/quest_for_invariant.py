import numpy as np
import pandas as pd
from step2.functions_2 import fit_garch

#This script applies the second step - Quest for invariance

def step2():

    # 1. load data

    #path = '/Users/heruojing/Desktop/ARPM/results/'

    risk_drivers_series = pd.read_csv('db_riskdrivers_series.csv',
                                      index_col=0, parse_dates=True)
    risk_drivers = risk_drivers_series.values
    dates = pd.to_datetime(np.array(risk_drivers_series.index))
    risk_drivers_names = risk_drivers_series.columns.values


    db_riskdrivers_tools = pd.read_csv('db_riskdrivers_tools.csv')
    n_stocks = int(db_riskdrivers_tools.n_stocks[0])
    d_impvol = int(db_riskdrivers_tools.d_impvol[0])

    del risk_drivers_series, db_riskdrivers_tools

    t_ = len(dates)-1  # length of the invariants time series

    # initialize temporary databases
    invariants = {}
    step2models = {}
    garch_sigma2 = {}
    garch_param = {}
    param_names = ['a', 'b', 'c', 'mu']


    # 2. GARCH(1,1) fit on stocks

    for i in range(n_stocks):
        # time series of increments
        dx = np.diff(risk_drivers[:, i])
        # fit
        param, sigma2, epsi = fit_garch(dx)
        # store next-step function and invariants
        invariants[i] = np.array(epsi)
        step2models[i] = 'GARCH(1,1)'
        garch_sigma2[i] = sigma2
        garch_param[i] = param

    # 3. GARCH(1,1) fit on index

    # time series of increments
    dx = np.diff(risk_drivers[:, n_stocks])
    # fit
    param, sigma2, epsi= fit_garch(dx)         #delete *_
    # store next-step function and invariants
    invariants[n_stocks] = np.array(epsi)
    step2models[n_stocks] = 'GARCH(1,1)'
    garch_sigma2[n_stocks] = sigma2
    garch_param[n_stocks] = param


    # 4. random walk fit on options

    for i in range(n_stocks+1, n_stocks+1+d_impvol):
        invariants[i] = np.diff(risk_drivers[:, i])
        step2models[i] = 'Random walk'
        garch_param[i] = np.full(4, np.nan)


    # 5. save database

    dates = dates[1:]

    out = pd.DataFrame({risk_drivers_names[i]: invariants[i]
                        for i in range(len(invariants))}, index=dates)
    out = out[list(risk_drivers_names[:len(invariants)])]
    out.index.name = 'dates'
    out.to_csv('db_invariants_series.csv')
    del out

    out = pd.DataFrame({risk_drivers_names[i]: step2models[i]
                        for i in range(len(step2models))}, index=[''])
    out = out[list(risk_drivers_names[:len(step2models)])]
    out.to_csv('db_invariants_step2models.csv',
               index=False)
    del out

    out = pd.DataFrame({risk_drivers_names[i]: garch_sigma2[i]
                        for i in range(len(garch_sigma2))}, index=dates)
    out.index.name = 'dates'
    out = out[list(risk_drivers_names[:len(garch_sigma2)])]
    out.to_csv('db_garch_sigma2.csv')
    del out

    out = pd.DataFrame({risk_drivers_names[i]: garch_param[i]
                        for i in range(len(garch_param))}, index=param_names)
    out = out[list(risk_drivers_names[:len(garch_param)])]
    out.to_csv('db_invariants_param.csv')
    del out
