import numpy as np
import pandas as pd
import scipy

from step3.functions_3 import data_scoring, data_smoothing, exp_decay_fp, conditional_fp, effective_num_scenarios

#This script applies the third step  - Estimation

def step3():

    """ 1. Load data"""

    #path = '/Users/heruojing/Desktop/ARPM/results/'

    # VIX (used for time-state conditioning)
    vix_path = 'vixdata.csv'
    vix = pd.read_csv(vix_path, usecols=['date', 'VIX_close'],
                      index_col=0)
    vix.index = pd.to_datetime(vix.index)

    # Risk drivers identification
    risk_drivers = pd.read_csv('db_riskdrivers_series.csv',
                               index_col=0, parse_dates=True)
    dates_rd = pd.to_datetime(np.array(risk_drivers.index))
    risk_drivers_names = risk_drivers.columns.values


    risk_driver_tools = pd.read_csv('db_riskdrivers_tools.csv')
    n_stocks = int(risk_driver_tools.n_stocks[0])
    d_impvol = int(risk_driver_tools.d_impvol[0])


    # Quest for invariance
    invariants = pd.read_csv( 'db_invariants_series.csv',
                             index_col=0, parse_dates=True)
    epsi = invariants.values

    t_, i_ = np.shape(epsi)
    dates = pd.to_datetime(np.array(invariants.index))

    invariants_models = pd.read_csv( 'db_invariants_step2models.csv')



    """ 2. Input Parameters"""

    hl_prior = 4 * 252  # half life for prior probabilities (time conditioning)
    hl_smooth = 21  # half life for VIX comp. ret. smoothing
    hl_score = 5 * 21  # half life for VIX comp. ret. scoring
    # proportion of obs. included in the range for state conditioning
    alpha_leeway = 0.4



    """ 3. Setting the flexible probabilities"""

    # time and state conditioning on smoothed and scored VIX returns
    # state indicator: VIX compounded return realizations
    c_vix = np.diff(np.log(np.array(vix.loc[dates_rd].VIX_close)))
    # smoothing
    z_vix = data_smoothing(c_vix, hl_smooth)
    # scoring
    z_vix = data_scoring(z_vix, hl_score)
    # target value
    z_vix_star = z_vix[-1]
    # flexible probabilities
    p_prior = exp_decay_fp(t_, hl_prior)
    flexible_pro = conditional_fp(z_vix, z_vix_star, alpha_leeway, p_prior)[0]
    # effective number of scenarios
    ens = effective_num_scenarios(flexible_pro)

    print(" Effective number of scenarios is ", ens)



    """ 4. Estimation of invariants' distribution """

    # sort flexible probability according to epsi

    # p_sorted is the corresponding flexible probability of sorted epsi
    p_sorted = np.zeros(epsi.shape)
    # sorted epsi
    epsi_sorted = np.zeros(epsi.shape)
    for i in range(p_sorted.shape[1]):
        # p_ is probibility distribution of each variation
        p_ = [x for _, x in sorted(zip(epsi[:, i], flexible_pro))]
        # p is cumulative distribution of each variation
        p = np.cumsum(p_)
        epsi_sorted[:, i] = sorted(epsi[:, i])
        # p_sorted is the cumulative p
        p_sorted[:, i] = p


    # compute the correlation of unsorted invariance
    cor, _ = scipy.stats.spearmanr(epsi)

    # find x given cdf
    def find_x_given_cdf(arr, p_list, p):
        # the smallest element of p_list bigger than p
        second = min([i for i in p_list if i >= p], key=lambda x: abs(x - p))
        p_list = p_list.tolist()
        # the location of corresponding closest cdf, which is bigger than what we are finding in the list
        loc_s = p_list.index(second)
        # the location of corresponding closest cdf, which is smaller than what we are finding in the list
        loc_f = loc_s - 1

        remainder = p - p_list[loc_f]
        # use interpolation to find the exact x
        x = arr[loc_f] + (arr[loc_s] - arr[loc_f]) * remainder
        return x

    # estimation of invariants, samplesize = 5000
    invariants_estimate = []
    for i in range(5000):
        #counter
        if i%500==0:
            print("samping to",i,"continuing...")
        if i==5000-1:
            print("sampling completed")
        # use multivariate normal to generate data, mean = 0, var = correlation
        random = np.random.multivariate_normal(np.zeros(epsi.shape[1]), cor)
        # find normal cdf corresponding to the random number generated prev step
        cdf = scipy.stats.norm(0, 1).cdf(random)
        # X contains all invariants found in the same time spread
        X = []
        for j in range(epsi.shape[1]):
            X.append(find_x_given_cdf(epsi_sorted[:, j], p_sorted[:, j], cdf[j]))
        invariants_estimate.append(X)



    """ 5.  Save Database"""

    out = pd.DataFrame({'p': flexible_pro}, index=dates)
    out.to_csv('db_estimation_flexprob.csv')
    del out

    out = pd.DataFrame(invariants_estimate,
                       columns=risk_drivers_names)
    out.to_csv( 'db_estimation_invariants.csv')
    del out