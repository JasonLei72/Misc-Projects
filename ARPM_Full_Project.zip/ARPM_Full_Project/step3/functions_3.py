import numpy as np
from scipy.stats import t as tstu


def data_smoothing(s, hl_smooth):
    """This function computes the smoothed version of the input signal s given
    the half life parameter tauHL_smooth
    """

    t_ = s.shape[0]
    times = np.arange(t_)
    s_smooth = np.zeros(t_)

    # smoothing
    for t in range(t_):
        p_smooth_t = np.exp(-np.log(2) / hl_smooth * (np.tile(t, t + 1) -
                            times[:t+1]))
        gamma_t = np.sum(p_smooth_t)
        s_smooth[t] = np.sum(p_smooth_t * s[:t+1]) / gamma_t

    return s_smooth

def data_scoring(s, hl_score):
    """This function computes the scored version of the input signal s given
    the half life parameter tau_hl_scor
    """

    t_ = s.shape[0]
    s_score = np.zeros(t_)

    mu_hat = data_smoothing(s, hl_score)
    mu2_hat = data_smoothing(s ** 2, hl_score)
    sd_hat = np.sqrt(mu2_hat - mu_hat**2)

    s_score[1:] = (s[1:] - mu_hat[1:]) / sd_hat[1:]
    s_score[0] = mu_hat[0]

    return s_score


def exp_decay_fp(t_, hl):
    """ This function computes exponentially decaying flexible probabilities
    with given half-life
    """

    p = np.exp(-(np.log(2) / hl) * np.arange(t_, 0, -1))
    p = p / np.sum(p)
    return p


def smooth_quantile(c, x, p=None):
    """ This function computes the smooth quantile at a given confidence level
    of a scenario-probability distribution
    """
    import scipy as sp
    j_ = len(x)

    #  if the probabilities are not specified, set them to uniform

    if p is None:
        p = np.ones(j_) / j_

    #  sort scenarios and probabilities

    order = np.argsort(x)
    x_sort = x[order]
    p_sort = p[order]

    #  cumulative probabilities

    u_sort = np.append(0, np.cumsum(p_sort))

    #  compute weights

    h = 0.25 * (j_ ** (-0.2))
    w = np.diff(sp.stats.norm.cdf(u_sort, c, h))
    w = w / np.sum(w)

    # Step 4: compute smooth quantile

    q = x_sort @ w

    return q, w, order


def min_rel_entropy_sp(p_pri, v_ineq=None, m_ineq=None, v_eq=None, m_eq=None,
                       normalize=True):
    """This function minimizes the relative entropy between two distributions
    given a set of equality and inequality views constraints.
    """

    from scipy.optimize import minimize
    from scipy.misc import logsumexp
    from scipy.sparse import eye
    if v_ineq is None and v_eq is None:
        # if there is no constraint, then just return p_pri
        return p_pri
    elif v_ineq is None:
        # no inequality constraints
        v = v_eq
        m = m_eq
        k_ineq = 0
        k_eq = len(m_eq)
    elif v_eq is None:
        # no equality constraints
        v = v_ineq
        m = m_ineq
        k_ineq = len(m_ineq)
        k_eq = 0
    else:
        v = np.concatenate((v_ineq, v_eq), axis=0)
        m = np.concatenate((m_ineq, m_eq), axis=0)
        k_ineq = len(m_ineq)
        k_eq = len(m_eq)

    k_ = k_ineq + k_eq  # dimension of the Lagrange dual problem

    if normalize is True:
        # normalize the constraints
        m_v = np.mean(v, axis=1)
        s_v = np.std(v, axis=1)
        v = ((v.T - m_v) / s_v).T
        m = (m - m_v) / s_v

    # pdf of a discrete exponential family
    def exp_family(theta):
        x = theta @ v + np.log(p_pri)
        phi = logsumexp(x)
        p = np.exp(x - phi)
        p[p < 1e-32] = 1e-32
        p = p / np.sum(p)
        return p

    # minus dual Lagrangian
    def lagrangian(theta):
        x = theta @ v + np.log(p_pri)
        phi = logsumexp(x)  # stable computation of log sum exp
        return phi - theta @ m

    def gradient(theta):
        return v @ exp_family(theta) - m

    def hessian(theta):
        p = exp_family(theta)
        v_ = v.T - v @ p
        return (v_.T * p) @ v_

    theta0 = np.zeros(k_)  # intial value

    if k_ineq == 0:
        # if no constraints, then perform the Newton conjugate gradient
        # trust-region algorithm
        options = {'gtol': 1e-10}
        res = minimize(lagrangian, theta0, method='trust-ncg',
                       jac=gradient, hess=hessian, options=options)
    else:
        # otherwise perform sequential least squares programming
        options = {'ftol': 1e-10, 'disp': False, 'maxiter': 1000}
        alpha = -eye(k_ineq, k_)
        constraints = {'type': 'ineq',
                       'fun': lambda theta: alpha @ theta}
        res = minimize(lagrangian, theta0, method='SLSQP', jac=gradient,
                       constraints=constraints, options=options)

    return exp_family(res['x'])


def conditional_fp(z, z_star, alpha, prior):
    """Flexible probabilities based on state conditioning, computed via minimum
    relative entropy
    """

    if isinstance(z_star, float) or isinstance(z_star, int):
        z_star = np.array([z_star])

    t_ = z.shape[0]
    k_ = z_star.shape[0]

    # Step 1: Crisp probabilities
    z_grid = np.unique(np.sort(z))
    pdf, _ = np.histogram(z, bins=np.insert(z_grid, 0, -np.inf), weights=np.ones(t_) / t_)
    cdf_z = np.cumsum(pdf)
    uni_cdf_z = np.unique(cdf_z)
    cdf_zz = np.interp(z_star, z_grid, uni_cdf_z)

    zmin, _, _ = smooth_quantile(alpha / 2, z_grid)
    zmax, _, _ = smooth_quantile(1 - alpha / 2, z_grid)

    z_lb = np.zeros(k_)
    z_ub = np.zeros(k_)
    p_crisp = np.zeros((k_, t_))
    pp = np.zeros((k_, t_))

    # Compute crisp probabilities
    for k in range(k_):
        cdf_zz[cdf_zz >= 1 - alpha / 2] = 1 - alpha / 2
        cdf_zz[cdf_zz <= alpha / 2] = alpha / 2

        z_grid = z_star[k]
        if z_grid <= zmin:
            z_lb[k] = np.min(z)
            z_ub[k], _, _ = smooth_quantile(cdf_zz[k] + alpha / 2, z)
        elif z_grid >= zmax:
            z_lb[k], _, _ = smooth_quantile(cdf_zz[k] - (alpha / 2), z)
            z_ub[k] = np.max(z)
        else:
            z_lb[k], _, _ = smooth_quantile(cdf_zz[k] - (alpha / 2), z)
            z_ub[k], _, _ = smooth_quantile(cdf_zz[k] + (alpha / 2), z)

        # crisp probabilities
        pp[k, (z <= z_ub[k]) & (z >= z_lb[k])] = 1
        p_crisp[k, :] = pp[k, :] / np.sum(pp[k, :])

    p_crisp[p_crisp == 0] = 10 ** -20

    for k in range(k_):
        p_crisp[k, :] = p_crisp[k, :] / np.sum(p_crisp[k, :])

    flexible_pro = np.zeros((k_, t_))

    # Step 2: Conditional flexible probabilities
    for k in range(k_):
        # moments
        m_z = p_crisp[k, :] @ z
        s2_z = p_crisp[k, :] @ (z ** 2) - m_z ** 2

        # constraints
        aineq = np.atleast_2d(z ** 2)
        bineq = np.atleast_1d((m_z ** 2) + s2_z)
        aeq = np.array([z])
        beq = np.array([m_z])

        # output
        flexible_pro[k, :] = min_rel_entropy_sp(prior, aineq, bineq, aeq, beq)

    return flexible_pro


def effective_num_scenarios(p, type_ent=None, gamma=None):
    """This function computes the effective number of scenarios determined by a
    set of flexible probabilities via different types of functions
    """

    if type_ent is None:
        type_ent = 'exp'

    if (type_ent == 'gen_exp') and (gamma is None):
        raise ValueError('Provide parameter of the generalized exponential')

    if type_ent == 'exp':
        p[p == 0] = 10 ** (-250)  # avoid log(0) in ens computation
        ens = np.exp(-p @ np.log(p))
    else:
        ens = np.sum(p ** gamma) ** (-1 / (gamma - 1))

    return ens

