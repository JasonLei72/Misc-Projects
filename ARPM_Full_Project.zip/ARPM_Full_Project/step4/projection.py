import numpy as np
import pandas as pd
import datetime
import matplotlib.pyplot as plt
from matplotlib._pylab_helpers import Gcf

# This script applies the fourth step - Projection

def step4():

    """ 1. Load data"""

    #path = '/Users/heruojing/Desktop/ARPM/results/'

    # load estimated invariants
    invariants_estimate_series = pd.read_csv('db_estimation_invariants.csv',
                              index_col=0, parse_dates=True)
    invariants_estimate = invariants_estimate_series.values
    N=invariants_estimate.shape[0]

    # load risk drivers
    risk_drivers_series = pd.read_csv('db_riskdrivers_series.csv',
                                        index_col=0, parse_dates=True)
    risk_drivers = risk_drivers_series.values
    dates = pd.to_datetime(np.array(risk_drivers_series.index))
    risk_drivers_names = risk_drivers_series.columns.values

    #current time risk drivers
    t_now = dates[-1]
    riskdriver_tnow = risk_drivers[-1,:]
    riskdriver_tnow_1 = risk_drivers[-2,:]

    # load risk driver tools
    db_riskdrivers_tools = pd.read_csv('db_riskdrivers_tools.csv')
    d_ = int(db_riskdrivers_tools.d_[0])
    n_stocks = int(db_riskdrivers_tools.n_stocks[0])
    d_impvol = int(db_riskdrivers_tools.d_impvol[0])

    # load garch model parameters
    invariants_param = pd.read_csv('db_invariants_param.csv', index_col=0)
    garch_sigma2 = pd.read_csv('db_garch_sigma2.csv', index_col=0,
                                     parse_dates=True)

    a = invariants_param.iloc[0,:n_stocks+1]
    b = invariants_param.iloc[1,:n_stocks+1]
    c = invariants_param.iloc[2,:n_stocks+1]
    mu = invariants_param.iloc[3,:n_stocks+1]


    """ 2. input parameters"""

    t_horizon = datetime.datetime(2012,10,26)
    estimate_time = 40
    sample_times = int(N/estimate_time)



    """ 3. projection for options"""

    # extract current risk driver and estimated invariants
    invariants_estimate_option = invariants_estimate[:,n_stocks+1:]
    option_rd_tnow = riskdriver_tnow[n_stocks+1:]
    option_names = risk_drivers_names[n_stocks+1:]

    # projection of future risk drivers
    projection_riskdrivers_option = {}


    for n in range(sample_times):
        projection_riskdrivers_option[41 * n] = option_rd_tnow

        #projection by applying random walk
        for i in range(1,estimate_time+1):
            projection_riskdrivers_option[41 * n + i] = projection_riskdrivers_option[41 * n + i - 1] + invariants_estimate_option[40 * n + i - 1]



    """ 3. projection for stocks"""

    # extract current risk driver and estimated invariants
    invariants_estimate_stock = invariants_estimate[:,:n_stocks+1]
    stock_rd_tnow = riskdriver_tnow[:n_stocks+1]
    stock_rd_tnow_d = riskdriver_tnow[:n_stocks+1] - riskdriver_tnow_1[:n_stocks+1]
    garch_sigma2_tnow = garch_sigma2.iloc[-1,:]
    stock_names = risk_drivers_names[:n_stocks+1]

    # projection of future risk drivers
    projection_riskdrivers_stock = {}
    projection_garch_sigma2 = {}

    for n in range(sample_times):

        projection_garch_sigma2[41*n] = garch_sigma2_tnow
        projection_riskdrivers_stock[41 * n] = stock_rd_tnow

        # projection by applying garch(1,1)
        projection_garch_sigma2[41*n+1] = c+b*projection_garch_sigma2[41*n]+a*(stock_rd_tnow_d-mu)**2
        projection_riskdrivers_stock[41*n+1] = mu + projection_riskdrivers_stock[41*n]\
                                               + projection_garch_sigma2[41*n+1]*invariants_estimate_stock[40*n]


        for i in range(2,estimate_time+1):
            projection_garch_sigma2[41*n+i] = c + b * projection_garch_sigma2[41*n+i-1]\
                                              +a * (projection_riskdrivers_stock[41*n+i-1]-projection_riskdrivers_stock[41*n+i-2]-mu)**2
            projection_riskdrivers_stock[41*n+i] = mu + projection_riskdrivers_stock[41*n+i-1] \
                                                   + projection_garch_sigma2[41*n+i]*invariants_estimate_stock[40*n+i-1]





    """ 4. save database"""

    projection_stock = pd.DataFrame.from_dict(projection_riskdrivers_stock, orient = 'index')
    projection_stock.columns = stock_names
    projection_option = pd.DataFrame.from_dict(projection_riskdrivers_option, orient = 'index')
    projection_option.columns = option_names
    projection_riskdrivers = pd.merge(projection_stock, projection_option, left_index=True, right_index=True)

    out = projection_riskdrivers
    out.to_csv( 'db_projection_riskdrivers.csv', index=None)
    del out

    out = pd.DataFrame({'j_': pd.Series(sample_times),
                        'thor': pd.Series(t_horizon),
                        'n_days':pd.Series(estimate_time)})
    out.to_csv('db_projection_tools.csv', index=None)
    del out



    """ 5. plots"""

    #plot a path of projection
    plt.style.use('seaborn')

    plt.figure(figsize= (12,6))
    x= np.arange(0,40)
    for d in range(sample_times):
        plt.plot( x, projection_option[option_names[0]][41*d:41*d+40])
    plt.title('projection of '+option_names[0], fontweight='bold')
    plt.xlabel('time (days)')
    plt.ylabel('risk driver projection')

    plt.savefig('figure_projection.png')
    plt.show(block=False)