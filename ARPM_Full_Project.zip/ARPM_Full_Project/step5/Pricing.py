import numpy as np
import pandas as pd
from scipy import interpolate
from step5.function_5 import bsm_price

# This script applies the fifth step - pricing

def step5():
    
    
    """Step0: Load data"""
    # Risk drivers identification
    db_v_tnow = pd.read_csv('db_v_tnow.csv') 																						# database of assets' value
    v_tnow = db_v_tnow.values[0] 																																														# array of values
    db_riskdrivers_series = pd.read_csv('db_riskdrivers_series.csv',index_col=0) 				# database of risk drivers
    riskdriver_series_values = db_riskdrivers_series.values 										 																							# array of risk drivers' values
    db_riskdrivers_tools = pd.read_csv('db_riskdrivers_tools.csv')				
    d_ = int(db_riskdrivers_tools['d_'][0])																																										# value of d_
    n_stocks = int(db_riskdrivers_tools['n_stocks'][0])																																				# number of stocks 


    #number of instruments, + 3 because of index SPX, put and call option
    n_instruments = n_stocks+3																																																# number of assets
    d_impvol = int(db_riskdrivers_tools['d_impvol'][0])
    tend_option = pd.to_datetime(db_riskdrivers_tools['tend_option'][0])    																									# value of t_end
    k_strike = db_riskdrivers_tools['k_strike'][0]																																						# strike price
    l_ = int(db_riskdrivers_tools['l_'][0])		   																																							# length of tau
    n_grid_option = int(db_riskdrivers_tools['n_grid_option'][0])																															# value of n_grid
    tau_implvol = db_riskdrivers_tools['tau_implvol'].values																																	# array of tau values	
    y = db_riskdrivers_tools['y'][0]																																													# risk free rate
    m_moneyness = db_riskdrivers_tools['m_moneyness'].values[:n_grid_option+1] 																								# n_grid + 1

    # Projection
    db_projection_tools = pd.read_csv('db_projection_tools.csv')
    j_ = int(db_projection_tools['j_'][0])																																										# number of scenarios
    thor = pd.to_datetime(db_projection_tools['thor'][0])																																			# value of t_hor
    p = np.ones(j_)/j_                                      																							  									# scenario probability
    tnow = pd.to_datetime(db_riskdrivers_series.index[-1])  																																	# value of t_now
    n_weekdays = int(db_projection_tools['n_days'][0])
    # number of weekdays between t_now and t_hor

    db_projection_riskdrivers = pd.read_csv('db_projection_riskdrivers.csv')
    riskdriver_series_values_proj = db_projection_riskdrivers.values.reshape(j_, n_weekdays+1, d_) 														# reshape the datafram for projection of riskdriver 
    pi_tnow_thor = np.zeros((j_, n_instruments))																																							# PnL from t_now to (t_now + t_hor)

    """Step1: Stock"""
    for n in range(n_stocks):																																																	# construct PnL for the stocks
        pi_tnow_thor[:, n] = v_tnow[n] * (np.exp(riskdriver_series_values_proj[:, -1, n] - riskdriver_series_values[-1, n])-1)	

    """Step2: S&P Index"""																																																		# construct PnL for the index
    pi_tnow_thor[:, n_stocks] = v_tnow[n_stocks]*(np.exp(riskdriver_series_values_proj[:, -1, n_stocks] - riskdriver_series_values[-1, n_stocks])-1)  
    
    """Step3: Option"""
    # time to expiry of the options at thor
    tau_opt_thor = np.timedelta64(np.datetime64(tend_option) - np.datetime64(thor), 'D')/np.timedelta64(252, 'D')

    v_call_thor = np.zeros(j_)																																																# construct series for V_call
    v_put_thor = np.zeros(j_)														    																																	# construct series for V_put
    mon_thor = np.zeros(j_)																																																		# construct series for moneyness
    logsigma_interp = np.zeros(j_)   																																													# construct series for interpolation

    # underlying and moneyness at the horizon
    s_thor = np.exp(riskdriver_series_values_proj[:, -1, n_stocks])																														# underlying value at t_horizon of each scenarios
    mon_thor = np.log(s_thor/k_strike)/np.sqrt(tau_opt_thor)																																	# calculate moneyness

    # log-implied volatility at the horizon
    logsigma_thor = riskdriver_series_values_proj[:, -1, n_stocks+1:n_stocks+d_impvol+1].reshape(j_, l_, n_grid_option+1)	

    # interpolate log-implied volatility
    for j in range(j_):
        # add grid points
        points = list(zip(*[grid.flatten() for grid in np.meshgrid(*[tau_implvol, m_moneyness])]))
        # known values
        values = logsigma_thor[j, :, :].flatten('F')
        # interpolation
        moneyness_hor = min(max(mon_thor[j], min(m_moneyness)), max(m_moneyness))
        logsigma_interp[j] = interpolate.LinearNDInterpolator(points, values)(*np.r_[tau_opt_thor, moneyness_hor])

    # compute call option value by means of Black-Scholes-Merton formula
    v_call_thor = bsm_price(s_thor, k_strike, y, tau_opt_thor, np.exp(logsigma_interp))

    # compute put option value by means of Black-Scholes-Merton formula
    v_put_thor = bsm_price(s_thor, k_strike, y, tau_opt_thor, np.exp(logsigma_interp), 0, -1)
    
    # compute P&L's
    pi_tnow_thor[:, n_stocks+1] = v_call_thor - v_tnow[n_stocks+1]
    pi_tnow_thor[:, n_stocks+2] = v_put_thor - v_tnow[n_stocks+2]



    """Save database"""
    """need to change path"""
    out = {db_v_tnow.columns[n]: pi_tnow_thor[:, n] for n in range(n_instruments)}
    names = [db_v_tnow.columns[n] for n in range(n_instruments)]
    out = pd.DataFrame(out)
    out = out[list(names)]
    out.to_csv('db_pricing.csv',
               index=False)
    del out

