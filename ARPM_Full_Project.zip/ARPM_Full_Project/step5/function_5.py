import numpy as np
from scipy.stats import norm

# Black-Scholes function
def bsm_price(s, k, rf, tau, v, div=0, cp=1):
    d1 = (np.log(s / k) + (rf - div + 0.5*v**2) * tau) / (v * np.sqrt(tau))
    d2 = d1-v*np.sqrt(tau)

    optprice = cp*s*np.exp(-div*tau)*norm.cdf(cp*d1) -  cp*k*np.exp(-rf*tau)*norm.cdf(cp*d2)

    return optprice