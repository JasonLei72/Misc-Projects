import numpy as np
import pandas as pd
# import scipy as sp
# import scipy.stats
# import matplotlib.pyplot as plt
# from matplotlib._pylab_helpers import Gcf



# This script applies to the sixth step - Aggregation


def step6():
    
    """Step0: Load data"""
    # Risk drivers identification
    db_riskdrivers_tools = pd.read_csv('db_riskdrivers_tools.csv')			# import tools for risk drivers
    n_stocks = int(db_riskdrivers_tools['n_stocks'][0])									# number of stocks
    n_instruments = n_stocks+3																					# number of instruments											
    db_v_tnow = pd.read_csv('db_v_tnow.csv')														# database of assets' value
    v_tnow = db_v_tnow.values[0]																				# asset values at time now

    # Projection
    db_projection_tools = pd.read_csv('db_projection_tools.csv')				# import tools for projection
    j_ = int(db_projection_tools['j_'][0])															# number of scenarios
    p = np.ones(j_)/j_				                                					# scenario probability

    # Pricing
    db_pricing = pd.read_csv('db_pricing.csv')													# PnL database
    pi_tnow_thor = db_pricing.values[:, :n_instruments]									# PnL

    
    """Step 1: Aggregation"""
    v_stock_budg_tnow = 700000																						# Set budget for stocks
    h_stock = np.zeros((n_stocks, 1))																		# Create a placeholder for stock holdings
    for n in range(n_stocks):																						# Evenly distribute budget to 7 stocks 
        h_stock[n, 0] = np.floor(v_stock_budg_tnow / n_stocks /v_tnow[n])	# and calculate the holding of each stock

    h_sp = np.array([[10]])																							# Holding of SPX index is 10

    h_opt_spx = np.array([[1], [1]])																    # Hold unit long position in SPX call and put

    # holdings
    h = np.r_[h_stock,
              h_sp,
              h_opt_spx]

    # budget at time tnow
    v_h_tnow = 1000000

    # cash at time tnow
    cash_tnow = v_h_tnow - h.T @ v_tnow                               # excess cash

    # ex-ante performance (P&L)
    y_h = pi_tnow_thor @ h                                              # total PnL of each scenario under given holdings


    """Step 2: Savedatabase"""
    out = {db_v_tnow.columns[i]: h[i]
           for i in range(len(h))}
    out = pd.DataFrame(out)
    out = out[list(db_v_tnow.columns[:len(h)])]
    out.to_csv('db_holdings.csv', index=False)
    del out


    out = pd.DataFrame({'Y_h': pd.Series(y_h.T[0])})
    out.to_csv('db_exante_perf.csv', index=False)
    del out


    out = pd.DataFrame({'v_h_tnow': v_h_tnow,
                        'cash_tnow': cash_tnow,
                        'v_stock_budg_tnow': v_stock_budg_tnow})
    out.to_csv('db_aggregation_tools.csv', index=False)
