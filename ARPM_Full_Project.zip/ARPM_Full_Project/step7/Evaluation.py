import numpy as np
import pandas as pd


# The script applies to the seventh step - Evaluation


def step7():
    # utility function: utility = -np.exp(-lamda * y)
    lamda = 0.003  # parameter of exponential utility function

    """Step 0: Load Data"""
    # Risk drivers identification
    db_riskdrivers_tools = pd.read_csv('db_riskdrivers_tools.csv')  # tools for risk drivers
    n_stocks = int(db_riskdrivers_tools['n_stocks'][0])																									  # number of stocks
    n_instruments = n_stocks+3																																					  # number of instruments

    # Projection
    db_projection_tools = pd.read_csv('db_projection_tools.csv')	  # import tools for projection
    j_ = int(db_projection_tools['j_'][0])                           																			# number of scenarios
    p = np.ones(j_)/j_				                                																						# scenario probability

    # Pricing
    db_pricing = pd.read_csv('db_pricing.csv')											# PnL database
    pi_tnow_thor = db_pricing.values[:, :n_instruments]																										# PnL

    # Aggregation
    db_exante_perf = pd.read_csv('db_exante_perf.csv')							# import ex-ante performance database		
    y_h = db_exante_perf.values																																						# 5000 scenarios of PnL (performance)
    db_holdings = pd.read_csv('db_holdings.csv')										# import holdings of each asset
    # h = np.squeeze(db_holdings.values)																																  # holdings array
    h = db_holdings.values[0]

    """Step 1: Calculate certainty equivalent index of satisfaction"""
    expected_utility = p@(-np.exp(-lamda*y_h))  																													# expected utility computation


    # certainty-equivalent
    satis_h_ce = -(1 / lamda)*np.log(-expected_utility)																										

    """Step 2: Quantile index of satisfaction"""
    c_quantile = 0.95  																																										# confidence level

    # quantile
    satis_h_q = np.percentile(pi_tnow_thor@h,(1-c_quantile)*100)																					# satisfaction value corresponding to 95% quantile
    # satis_h_q, _ = smooth_quantile_port(c_quantile, pi_tnow_thor, h, p)


    """Step 3: cVaR index of satisfaction"""
    c_es = 0.95																																														# confidence interval for expected shortfall

    # compute the cVaR through the dual representation
    # sort the rows of y_h
    y_h_sort, indx = np.sort(y_h, axis=0), np.argsort(y_h, axis=0)																				# sort y_h and respective index
    p_sort = p[indx]
    j_c = np.where(np.cumsum(p_sort) >= 1-c_es)[0][0]                                                     # the starting index where cumulative probability greater than 1-c_es
    q_sort = np.zeros(j_)
    for j in range(j_c):
        q_sort[j] = 1/(1-c_es)*p_sort[j]

    # cVaR
    satis_h_es = q_sort @ y_h_sort


    """Step 4: Variance index of satisfaction"""
    # _, satis_h_variance = meancov_sp(y_h, p)
    satis_h_variance = -np.var(y_h)
    # satis_h_variance = -satis_h_variance[0, 0]


    """Save database"""
    out = pd.DataFrame({'c_quantile': pd.Series(c_quantile),
                        'c_es': pd.Series(c_es),
                        'satis_h_q': pd.Series(satis_h_q),
                        'satis_h_es': pd.Series(satis_h_es),
                        'satis_h_variance': pd.Series(satis_h_variance),
                        'satis_h_ce': pd.Series(satis_h_ce)})
    out.to_csv('db_quantile_and_satis.csv', index=False)
    del out