import numpy as np
import pandas as pd


from step8.function_8 import meancov_sp, fit_lfm_ols, fit_lfm_lasso


def step8():
    

    """Step0: Load data"""
    # Risk drivers identification
    db_riskdrivers_tools = pd.read_csv('db_riskdrivers_tools.csv')			# tools for risk drivers
    d_ = int(db_riskdrivers_tools['d_'][0])																																		# value of d_
    n_stocks = int(db_riskdrivers_tools['n_stocks'][0])																												# number of stocks	
    n_instruments = n_stocks+3                                                                                           # number of assets
    db_riskdrivers_series = pd.read_csv('db_riskdrivers_series.csv', index_col=0)
    riskdrivers = db_riskdrivers_series.values																																# risk drivers' values

    # Projection
    db_projection_tools = pd.read_csv('db_projection_tools.csv')
    j_ = int(db_projection_tools['j_'][0])																														        # number of scenarios
    thor = pd.to_datetime(db_projection_tools['thor'][0])																											# t_horizon							
    tnow = pd.to_datetime(pd.to_datetime(db_riskdrivers_series.index[-1]))																		# t_now
    m_ = int(db_projection_tools['n_days'][0])																																				# number of business days during t_horizon														

    db_projection_riskdrivers = pd.read_csv('db_projection_riskdrivers.csv')
    x_proj = db_projection_riskdrivers.values.reshape(j_, m_+1, d_)																						# risk drivers projection
    p = np.ones(j_)/j_				                                																								# scenario probability


    # Aggregation
    db_exante_perf = pd.read_csv('db_exante_perf.csv')
    y_h = db_exante_perf.values

    # Ex-ante evaluation
    db_quantile_and_satis = pd.read_csv('db_quantile_and_satis.csv')
    c_es = db_quantile_and_satis['c_es'][0]



    """Step 1: Ex-ante attribution: performance"""
    # Risk factors: risk drivers increments
    z = np.zeros((j_, d_))																						                             					# a matrix of # of simulations * # of risk drivers
    for d in range(d_):																																											# increment of risk drivers between horizon and t_now
      z[:, d] = x_proj[:, -1, d]-riskdrivers[-1, d]
    lambda1 = 6    

    alpha_h, beta_h, sig2_u_h, u_h = fit_lfm_lasso(y_h, z, p, lambda1, 0)																		 # return alpha and selected betas
    u_h = u_h.reshape(1, -1)
    ind_relevant_risk_factors = np.where(beta_h != 0)[0]

    istr = 'Number of relevant risk factors: ' + str(len(ind_relevant_risk_factors))
    print(istr)
    del lambda1



    """Step 2: Ex-ante attribution: risk"""
    z_0 = (alpha_h + u_h)/np.sqrt(sig2_u_h)																																	# risk factor for residual
    beta_0 = np.sqrt(sig2_u_h)																																	            # beta for residual

    z_new = np.r_[z_0, z.T]																																									# concatenate two arrays
    beta_new = np.array([np.append(beta_0, beta_h)])
    k_ = z_new.shape[0]																																								      # number of factors

    # marginal contributions to the cVaR
    satis_beta_k_es = np.zeros((1, k_))																																			# similar process as the one in "cVaR index of satisfaction" in step 7 section
	
    index = np.argsort(y_h, axis=0)
    p_sort = p[index]
    z_new_sort = z_new[:, index]																																						# sort the joint factors (from residual and those selected by Lasso)

    j_c = np.where(np.cumsum(p_sort) >= 1-c_es)[0][0]

    q_sort = np.zeros((j_, 1))
    for j in range(j_c):
        q_sort[j] = 1/(1-c_es)*p_sort[j]

    for k in range(k_):
        satis_beta_k_es[0, k] = beta_new[0, k] * (q_sort.T @ z_new_sort[k, :])

    # marginal contributions to the variance index of satisfaction
    satis_beta_k_variance = np.zeros((1, k_))
    cov_z_new = np.cov(z_new)																																							# covariance of z_new
    # _, cov_z_new = meancov_sp(z_new.T, p)
    for k in range(k_):
        cov_z_new_beta = cov_z_new @ beta_new.T
        satis_beta_k_variance[0, k] = -beta_new[0, k] * cov_z_new_beta[k, 0]
    