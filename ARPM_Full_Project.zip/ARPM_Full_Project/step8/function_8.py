import numpy as np
from sklearn.linear_model import Lasso


def meancov_sp(x, p=None):
    if p is None:
        t_ = x.shape[0]
        p = np.ones(t_) / t_  # equal probabilities as default value

    m = p @ x
    s2 = ((x-m).T*p) @ (x-m)
    return m, s2


def fit_lfm_ols(x, z, p=None, fit_intercept=True):
    t_ = x.shape[0]

    if len(z.shape) == 1:
        z = z.reshape((t_, 1))

    if len(x.shape) == 1:
        x = x.reshape((t_, 1))
        n_ = 1
    else:
        n_ = x.shape[1]

    if p is None:
        p = np.ones(t_) / t_

    if fit_intercept is True:

        # Step 1: Compute HFP mean and covariance

        m_xz, s2_xz = meancov_sp(np.concatenate((x, z), axis=1), p)

        # Step 2: Compute the OLSFP estimates

        beta = np.linalg.solve(s2_xz[n_:, n_:], s2_xz[n_:, :n_])
        alpha = m_xz[:n_] - m_xz[n_:] @ beta
    else:

        # Step 3: Compute the OLSFP estimates without intercept

        beta = np.linalg.solve((z.T*p) @ z, (z.T*p) @ x)
        alpha = np.zeros(n_)

    # Step 4: Compute residual and covariance

    u = x - alpha - z @ beta
    _, s2_u = meancov_sp(u, p)
    if beta.shape[0] == 1:
        beta = beta[0]
    else:
        beta = beta.T

    return alpha, beta, s2_u, u


def fit_lfm_lasso(x, z, p=None, lam=1e-2, fit_intercept=True):
    if len(x.shape) == 1:
        x = x.reshape(-1, 1)

    if len(z.shape) == 1:
        z = z.reshape(-1, 1)

    t_, n_ = x.shape
    k_ = z.shape[1]

    if p is None:
        p = np.ones(t_) / t_

    if lam == 0:
        alpha, beta, s2_u, u = fit_lfm_ols(x, z, p, fit_intercept)
    else:
        if fit_intercept is True:
            m_x = p @ x
            m_z = p @ z
        else:
            m_x = np.zeros(n_,)
            m_z = np.zeros(k_,)

        x_p = ((x - m_x).T * np.sqrt(p)).T
        z_p = ((z - m_z).T * np.sqrt(p)).T

        clf = Lasso(alpha=lam/(2.*t_), fit_intercept=False)
        clf.fit(z_p, x_p)
        beta = clf.coef_

        if k_ == 1:
            alpha = m_x - beta * m_z
            u = x - alpha - z * beta
        else:
            alpha = m_x - beta @ m_z
            u = x - alpha - z @ np.atleast_2d(beta).T

        _, s2_u = meancov_sp(u, p)

    return alpha, beta, s2_u, u
