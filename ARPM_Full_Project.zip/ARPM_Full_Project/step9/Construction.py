import numpy as np
import pandas as pd
from cvxpy import Variable, Maximize, Problem, quad_form
import matplotlib.pyplot as plt

def step9():
    

    """Input parameters"""
    v_stock_budg = 20000																																					  				# budget for stocks
    lambda_span = np.arange(0.0001, 0.1, 0.0001)																														# array for lamda values from 0.0001 to 0.1


    """Step0: Load data"""
    # Risk drivers identification
    db_riskdrivers_tools = pd.read_csv('db_riskdrivers_tools.csv')		# tools for risk drivers
    n_stocks = int(db_riskdrivers_tools['n_stocks'][0])																					           	# number of stocks
    n_instruments = n_stocks+3																																							# number of assets
    db_v_tnow = pd.read_csv('db_v_tnow.csv')													# value of assets
    v_tnow = db_v_tnow.values[0]																						

    # Projection
    db_projection_tools = pd.read_csv('db_projection_tools.csv')			# tools for projection
    j_ = int(db_projection_tools['j_'][0])																																	# number of scenarios
    p = np.ones(j_)/j_ 																																                      # scenario probability

    # Pricing
    db_pricing = pd.read_csv('db_pricing.csv')
    pi_tnow_thor = db_pricing.values[:, :n_instruments]																																# PnL of each asset

    # Aggregation
    db_aggregation_tools = pd.read_csv('db_aggregation_tools.csv')		# Tools for aggregation
    v_h_tnow = db_aggregation_tools['v_h_tnow'][0]																											    # Total value for weighted assets # total budget
    v_stock_budg_tnow = db_aggregation_tools['v_stock_budg_tnow'][0]																				#	Budget for stocks
    db_exante_perf = pd.read_csv('db_exante_perf.csv')								# Exante performance		
    y_h = db_exante_perf.values																																							# PnL with weighted holdings

    # Ex-ante evaluation
    db_quantile_and_satis = pd.read_csv('db_quantile_and_satis.csv')	# Quantile and satisfaction
    c_es = db_quantile_and_satis['c_es'][0]																																	# Confidence level for expected shortfall


    """Step 1: Solving the first step of the mean-variance approach"""
    # Constraints:
    # 1) budget constraint h'*v_tnow = v_h_tnow
    # 2) invest at least v_stock_budg_tnow $ in stocks
    # compute expectation and covariance
    #exp_pi, cov_pi = meancov_sp(pi_tnow_thor, p)



    # exp_pi, cov_pi = meancov_sp(np.delete(pi_tnow_thor, n_stocks, 1), p)
    exp_pi = np.mean(np.delete(pi_tnow_thor, n_stocks, 1), 0)																								# Expectation for PnL
    cov_pi = np.cov(np.delete(pi_tnow_thor, n_stocks, 1).T)															                    # Variance for PnL
    h_lambda = np.zeros((n_instruments, len(lambda_span)))																	
    expectation = np.zeros((1, len(lambda_span)))
    variance = np.zeros((1, len(lambda_span)))

    for l in range(len(lambda_span)):

        # set quadratic programming variables
        h_qp = Variable(n_instruments-1)																												
        objective = Maximize(exp_pi*h_qp - quad_form(h_qp, lambda_span[l]*cov_pi))
        constraints = [np.delete(v_tnow, n_stocks, 0)*h_qp == v_h_tnow,
                       np.array([np.append(v_tnow[:n_stocks],
                                           np.zeros(2))])*h_qp >=
                       v_stock_budg,
                       h_qp >= 0]
        # solve quadratic programming problem
        prob = Problem(objective, constraints)
        prob.solve()
        expectation[:, l] = exp_pi@h_qp.value.T
        variance[:, l] = h_qp.value@cov_pi@h_qp.value.T
        h_lambda[:, l] = np.insert(h_qp.value, n_stocks, 0, axis=0)


    
    """Step 2: Solving the second step of the mean-variance approach"""
    # cVaR index of satisfaction
    satis_h_es_lambda = np.zeros((1, len(lambda_span)))

    for l in range(len(lambda_span)):
        y_h_lambda = pi_tnow_thor@h_lambda[:, [l]]
        y_h_sort, indx = np.sort(y_h_lambda, axis=0), np.argsort(y_h_lambda,
                                                                 axis=0)
        p_sort = p[indx]
        j_c = np.where(np.cumsum(p_sort) >= 1-c_es)[0][0]
        q_sort = np.zeros((1, j_))
        for j in range(j_c):
            q_sort[0, j] = 1/(1-c_es)*p_sort[j]
    
        # cVaR
        satis_h_es_lambda[0, l] = q_sort@y_h_sort


    ind_es_lambda_star = np.argmax(satis_h_es_lambda)																											# the index of the best cVaR
    h_es_qsi = np.floor(h_lambda[:, [ind_es_lambda_star]])																								# the optimal holdings
    satis_es_h_qsi = satis_h_es_lambda[0, ind_es_lambda_star]																							# satisfaction of optimal portfolio
    y_h_es_qsi = pi_tnow_thor@h_es_qsi																								                    # PnL of optimal portfolio

    lambda_span[ind_es_lambda_star]																								                        # the lambda that has the best performance


    """Plots"""
    plt.hist(y_h_es_qsi.T[0], bins=10)
    plt.hist(y_h.T[0], bins=10)
    plt.title("Optimized P&L Distribution")
    plt.ylabel("times")
    plt.xlabel("P&L")
    
    plt.savefig('P&L.png')
    plt.show(block=False)
    
    
    plt.figure()
    plt.plot(variance[0,:],expectation[0,:] , lw=1)
    plt.plot(variance[0,ind_es_lambda_star],expectation[0,ind_es_lambda_star] , 'ro' )
    plt.title("Efficient Frontier")
    plt.ylabel("Expected P&L")
    plt.xlabel("Variance")
    
    plt.savefig('efficient frontier.png')
    plt.show(block=False)

    """Save database"""
    out = {db_v_tnow.columns[i]: h_es_qsi[i] for i in range(len(h_es_qsi))}
    out = pd.DataFrame(out)
    out = out[list(db_v_tnow.columns[:len(h_es_qsi)])]
    out.to_csv('db_final_portfolio.csv', index=False)
    del out
    
    print('The optimal portfolio holdings: ')
    print(h_es_qsi)
    print('The expected return: ' + str(expectation[0,ind_es_lambda_star]))
    print('The expected variance: ' + str(variance[0,ind_es_lambda_star]))
